module.exports = {
    unit: {
        configFile: 'test/karma.conf.js',
        singleRun: true
    }
};
